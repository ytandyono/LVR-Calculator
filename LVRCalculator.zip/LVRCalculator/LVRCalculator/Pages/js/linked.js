﻿
document.getElementById('btnCalcLVR').addEventListener('click', function (event) {
    event.preventDefault(); checkQuantity();
});

function calculateLVR()
{
    let propValue = document.getElementById('txtPropertyValue').value;
    let borrowingValue = document.getElementById('txtBorrowingValue').value;

    let lvr = borrowingValue / propValue;

    document.getElementById('lvr').innerHTML = lvr;
}