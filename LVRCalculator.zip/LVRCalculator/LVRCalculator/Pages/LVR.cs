﻿namespace LVRCalculator.Pages
{
    public class LVR
    {
        public double CalculateLVR(double propertyValue, double borrowingValue)
        {
            return (borrowingValue / propertyValue)  ;
        }
    }
}
