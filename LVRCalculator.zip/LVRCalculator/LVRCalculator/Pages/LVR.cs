﻿using System.Diagnostics;
namespace LVRCalculator.Pages
{
    public class LVR
    {
        public double CalculateLVR(double propertyValue, double borrowingValue)
        {
            try 
            {
                if (propertyValue < 0)
                    throw new ArgumentOutOfRangeException("Property value cannot be a negative value");
                if (borrowingValue < 0)
                    throw new ArgumentOutOfRangeException("Borrowing value cannot be a negative value");
                if (borrowingValue > propertyValue)
                    throw new ArgumentOutOfRangeException("Borrowing value cannot be greater than property value");
            }
            catch (Exception ex)
            {
                //Not sure how to redirect to a page showing an error in web page. 
                Debug.WriteLine(ex.Message);
            }
            return (borrowingValue / propertyValue)  ;
        }
    }
}
